package students;


import login.*;
import database.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.*;
import javax.swing.JOptionPane;

public class connexion {

    Connection con = null;/* ww w .j a va2 s . co m*/
    public Connection getcon() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/bdd", "root",
                    "1234");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return con;
    }

    public void insertion(String nom, String password) {
        PreparedStatement pst;
        ResultSet rs;
        Connection con;
        try {
            connexion c = new connexion();
            con = c.getcon();
            System.out.println("Connection is:" + con);
            String requete = "INSERT INTO admins values(?,?) ";
            pst = con.prepareStatement(requete);
            pst.setString(1, nom);
            pst.setString(2, "" + password);
            pst.executeUpdate();

            JOptionPane.showMessageDialog(null,"Donnéers enregistré");

} catch (Exception e1) {
            e1.printStackTrace();
        }

    }

    public void affichaeResultat() {
        Statement pst;
        ResultSet rs;
        Connection con;

        try {
            connexion c = new connexion();
            con = c.getcon();
            System.out.println("Connection is:" + con);
            String requete = "Select * from admins";
            pst = con.createStatement();
            rs = pst.executeQuery(requete);
            while (rs.next()) {
//Récupérer par nom de colonne
                
                String nom = rs.getString("name");
                String pass = rs.getString("password");

                System.out.print(", Nom: " + nom);
                System.out.print(" password : " + pass);
                System.out.println("");
            }
//étape 6: fermez l'objet de connexion
            con.close();

        } catch (Exception e1) {
            e1.printStackTrace();
        }

    }

    public static void main(String[] args) {
                    


    }
}
